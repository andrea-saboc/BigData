.. include:: ../../../HACKING.rst.txt
