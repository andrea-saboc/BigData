.. automodule:: scipy.cluster.vq
   :no-members:
   :no-inherited-members:
   :no-special-members:
