.. _optimize.linprog-highs:

linprog(method='highs')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_highs_doc
   :method: highs
