.. _optimize.qap-2opt:

quadratic_assignment(method='2opt')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.quadratic_assignment
   :impl: scipy.optimize._qap._quadratic_assignment_2opt
   :method: 2opt
