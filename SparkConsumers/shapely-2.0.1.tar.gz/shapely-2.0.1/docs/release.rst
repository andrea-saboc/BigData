=============
Release notes
=============

.. toctree::
   :maxdepth: 2

   release/2.x
   release/1.x
