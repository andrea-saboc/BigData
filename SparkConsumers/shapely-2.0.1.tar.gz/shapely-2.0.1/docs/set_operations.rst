Set operations
==============

.. currentmodule:: shapely

.. autosummary::
   :toctree: reference/

{% for function in get_module_functions("set_operations") %}
   {{ function }}
{% endfor %}
