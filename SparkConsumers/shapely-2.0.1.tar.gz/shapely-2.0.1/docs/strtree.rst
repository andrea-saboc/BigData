STRTree
=======

.. autoclass:: shapely.STRtree
   :members:
